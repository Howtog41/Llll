TOKEN = '8266320488:AAEWtfJWtOFeSnC5zs9wnK6gSHDoO9Gq76g'
ADMIN_ID = 5018200809
MONGO_URI = 'mongodb+srv://latestkoreandraama:P5jRORGqeJsf9nDJ@cluster0.nnnuejc.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0'
